export const HMACTOR_TUNABLES = {
    flag: {
        dodge: false,
    },
    die: {
        trauma: 'd20',
    },
    sfatigue: {
        def: -6,
        basespd: 5,
    },
};
